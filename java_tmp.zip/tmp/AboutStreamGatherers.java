public class AboutStreamGatherers {
    public static void main(String[] args) {

    }
}
