public class First {
    void run() {
        System.out.println(First.class.getName());
    }
}
