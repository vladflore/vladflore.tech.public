public class Second {
    void run() {
        System.out.println(Second.class.getName());
    }
}
