
public class AboutRecordPatterns {

    public static void main(String[] args) {
        var circle = new Circle(new Point(1, 2), 3);
        var line = new Line(new Point(7, 7), new Point(77, 77));
        printShape(circle);
        printShape(line);
    }

    private static void printShape(Shape s) {
        if (s instanceof Circle) {
            var circle = (Circle) s;
            var txt = "Center: (%d, %d) Radius: %d".formatted(
                    circle.center().x(),
                    circle.center().y(),
                    circle.radius());
            System.out.println(txt);
        }

        if (s instanceof Circle(Point(int x, int y), int radius)) {
            var txt = "Center: (%d, %d) Radius: %d".formatted(x, y, radius);
            System.out.println(txt);
        }

        if (s instanceof Circle(Point(var x, var y), var radius)) {
            var txt = "Center: (%d, %d) Radius: %d".formatted(x, y, radius);
            System.out.println(txt);
        }

        var txt1 = switch (s) {
            case Circle(Point(var x, var y), var radius) -> "Center: (%d, %d) Radius: %d".formatted(x, y, radius);
            case Line(Point(var startX, var startY), Point(var endX, var endY)) ->
                "Start: (%d, %d) End: (%d, %d)".formatted(startX, startY, endX, endY);
        };
        System.out.println(txt1);
    }
}

record Point(int x, int y) {

}

record Circle(Point center, int radius) implements Shape {

}

record Line(Point start, Point end) implements Shape {

}

sealed interface Shape permits Circle, Line {
}
