import java.util.List;

public class AboutUnnamedVarsAndPatterns {
    public static void main(String[] args) {

        var words = List.of("one", "two", "three");
        var counter = 0;
        // we do not do anything with a word
        for (String _ : words) {
            counter++;
        }
        System.out.println(counter);

        var a = 1;
        var b = 2;
        // normally, the next line would be removed, in this case it illustrates a point
        var _ = 3;
        System.out.println(a + b);

        var notANumber = "boom";
        try {
            int _ = Integer.parseInt(notANumber);
        } catch (NumberFormatException _) {
            System.out.println("Bad number: " + notANumber);
        }

        System.out.println(generateText(new Circle(new Point(0, 0), 1)));
        System.out.println(generateText(new Line(new Point(1, 1), new Point(2, 2))));

    }

    private static String generateText(Shape s) {
        return switch (s) {
            // an example of unnamed pattern variable: `var _`, as we are not interested in
            // the circle's radius
            case Circle(Point(var x, var y), var _) -> "Center: (%d, %d)".formatted(x, y);

            // as we are not interested in the second point we can ignore it completely,
            // this is an example of a unnnamed pattern
            case Line(Point(var startX, var startY), _) ->
                "Start: (%d, %d)".formatted(startX, startY);
        };
    }

    record Point(int x, int y) {
    }

    sealed interface Shape permits Circle, Line {
    }

    record Circle(Point center, int radius) implements Shape {
    }

    record Line(Point start, Point end) implements Shape {
    }
}
