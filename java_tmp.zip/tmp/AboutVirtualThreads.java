import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

public class AboutVirtualThreads {
    public static void main(String[] args) throws InterruptedException {

        Runnable r = () -> {
            var tName = Thread.currentThread().getName();
            var isVirtual = Thread.currentThread().isVirtual();
            System.out.println("Hello from " + tName + ". Am I virtual? " + isVirtual);
        };

        var t1 = Thread.ofVirtual().name("my-virtual-thread-1").start(r);
        t1.join();

        var t2 = Thread.startVirtualThread(r);
        t2.setName("my-virtual-thread-2");
        t2.join();

        ThreadFactory tf = Thread.ofVirtual().name("my-virtual-thread-", 3).factory();
        try (var executor = Executors.newThreadPerTaskExecutor(tf)) {
            executor.submit(r);
        }

        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            executor.submit(r);
        }

        Thread t4 = Thread.ofPlatform().name("my-platform-thread-1").start(r);
        t4.join();
    }
}
