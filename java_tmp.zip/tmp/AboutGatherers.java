
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Gatherer;
import java.util.stream.Gatherers;
import java.util.stream.Stream;

public class AboutGatherers {

    public static void main(String[] args) {
        List<List<Integer>> result1
                = Stream.of(1, 2, 3, 4, 5, 6, 7, 8).gather(Gatherers.windowFixed(3)).toList();
        System.out.println("result1 = " + result1);

        List<List<Integer>> result2
                = Stream.of(1, 2, 3, 4, 5, 6, 7, 8).gather(Gatherers.windowSliding(2)).toList();
        System.out.println("result2 = " + result2);

        List<String> result3
                = Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
                        .gather(
                                Gatherers.scan(() -> "", (string, number) -> string + number)
                        )
                        .toList();
        System.out.println("result3 = " + result3);

        var result4 = Stream.iterate(1, n -> n + 1).limit(9).gather(
                Gatherers.mapConcurrent(3, n -> n * n)
        ).toList();
        System.out.println("result4 = " + result4);

        String result5
                = Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
                        .gather(
                                Gatherers.fold(() -> "", (string, number) -> string + number)
                        ).findFirst().orElse("");
        System.out.println("result5 = " + result5);

        var distinctByLength = Stream.of("a", "bc", "de", "fgh").gather(distinctByLength()).toList();
        System.out.println(distinctByLength);
    }

    public static Gatherer<String, Set<Integer>, String> distinctByLength() {
        return Gatherer.ofSequential(
                HashSet::new,
                (seen, element, downstream) -> {
                    if (downstream.isRejecting()) {
                        return false;
                    }
                    if (seen.add(element.length())) {
                        downstream.push(element);
                    }
                    return true;
                }
        );
    }
}
