public class JEP467 {

    /// ## Start of documentation
    ///
    /// This _documentation_ was written in Markdown.
    ///
    /// - `This`
    /// - is
    /// - cool.
    ///
    /// Simple tables are supported:
    ///
    /// | Latin | Greek |
    /// |-------|-------|
    /// | a     | alpha |
    /// | b     | beta  |
    ///
    /// This is some Java code:
    ///
    /// ```java
    /// System.out.println("Mind blowing");
    /// ```
    ///
    /// ## End of documentation
    public static void main(String[] args) {
        System.out.println(greet("Vlad"));
    }

    /// This method builds a greeting and gives it back.
    ///
    /// @param name the name to use in the greeting
    /// @return a greeting as a string
    public static String greet(String name) {
        return "Hello, %s!".formatted(name);
    }
}
