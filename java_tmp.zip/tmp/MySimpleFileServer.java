
import com.sun.net.httpserver.SimpleFileServer;
import com.sun.net.httpserver.SimpleFileServer.OutputLevel;
import java.net.InetSocketAddress;
import java.nio.file.Path;

public class MySimpleFileServer {

    /**
     *
     * {@snippet :
     * System.out.println("Hello, Snippet!");
     * }
     *
     * {@snippet class = UTF8ByDefault region = example}
     *
     */
    public static void main(String[] args) {
        var server = SimpleFileServer.createFileServer(new InetSocketAddress(8080),
                Path.of("/"),
                OutputLevel.VERBOSE);
        // @start region = my-region
        System.out.println("About to start the server...");
        // @end
        server.start();
    }
}
