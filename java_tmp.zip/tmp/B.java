public class B {
    public static void main(String[] args) {
        System.out.println("Hello, B!");
        // @start region = say-howdy
        System.out.println("Howdy, B!");
        // @end
    }
}
