public class JEP458 {
    public static void main(String[] args) {

        var first = new First();
        first.run();
        var second = new Second();
        second.run();
    }
}
