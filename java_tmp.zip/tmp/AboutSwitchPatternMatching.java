import java.util.regex.Pattern;

public class AboutSwitchPatternMatching {
    public static void main(String[] args) {
        // var colors = "red, blue, green,yellow, RED, Blue, grEEn, YELLow";
        // var pattern = Pattern.compile(",\\s*");
        // pattern.splitAsStream(colors)
        // .map(String::toUpperCase)
        // .map(Color::valueOf)
        // .map(AboutSwitchPatternMatching::translateColorToGerman)
        // .forEach(System.out::println);
        // System.out.println(translateColorToGermanString(null));
        // System.out.println(translateColorToGermanString("purple"));

        // System.out.println(translateColorToGerman(null));
        // System.out.println(translateColorToGerman(Color.PURPLE));

        String str = "this is a string";
        var res = switch (str) {
            // case CharSequence cs -> "A sequence of length: " + cs.length();
            case String s -> "A string: " + s;
            // case CharSequence cs -> "A sequence of length: " + cs.length();
            // default -> "Something else";
        };
        System.out.println(res);

    }

    private static String translateColorToGermanString(String colorInEnglish) {
        return switch (colorInEnglish) {
            case String s when s.equalsIgnoreCase("red") -> "rot";
            case String s when s.equalsIgnoreCase("blue") -> "blau";
            case String s when s.equalsIgnoreCase("green") -> "gruen";
            case String s when s.equalsIgnoreCase("yellow") -> "gelb";
            // case null -> "Unsupported color:" + colorInEnglish;
            // default -> "Unsupported color:" + colorInEnglish;
            case null, default -> "Unsupported color:" + colorInEnglish;
        };
    }

    private static String translateColorToGerman(Color colorInEnglish) {
        return switch (colorInEnglish) {
            case Color.RED -> "rot";
            case BLUE -> "blau";
            case Color.GREEN -> "gruen";
            case Color.YELLOW -> "gelb";
            case Color.PURPLE -> "lila";
            case null -> "Unsupported color:" + colorInEnglish;
        };
    }
}

enum Color {
    RED, BLUE, GREEN, YELLOW, PURPLE
}
