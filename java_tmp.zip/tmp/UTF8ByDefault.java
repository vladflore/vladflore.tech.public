public class UTF8ByDefault {
	public static void main(String[] args) {
		// @start region = example
		System.out.println("Hello, UTF-8!");
		// @end
	}
}
