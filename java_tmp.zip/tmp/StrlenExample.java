import java.lang.foreign.*;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;

public class StrlenExample {
    public static void main(String[] args) throws Throwable {
        // Link to the C standard library
        Linker linker = Linker.nativeLinker();
        SymbolLookup stdlib = linker.defaultLookup();

        // Find the symbol for 'strlen'
        MemorySegment strlenFunc = stdlib.find("strlen")
                .orElseThrow(() -> new RuntimeException("strlen not found"));

        // Define the method type: strlen(char*) -> long
        FunctionDescriptor strlenDesc = FunctionDescriptor.of(ValueLayout.JAVA_LONG, ValueLayout.ADDRESS);

        // Create a method handle for the native strlen function
        MethodHandle strlen = linker.downcallHandle(strlenFunc, strlenDesc);

        // Allocate memory for a C string
        try (Arena arena = Arena.ofConfined()) {
            MemorySegment cString = arena.allocateFrom("Hello, FFM!");

            // Call strlen on the C string
            long length = (long) strlen.invoke(cString);
            System.out.println("Length: " + length); // Output: 11
        }
    }
}
